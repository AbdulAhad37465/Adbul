# Airline-Reservation-System
This is a project done in java,mysql and contains functionalities like searching flights,book tickets,cancel tickets etc..<br>
I have attached a sql file so that you can run the file and create database.<br>
<b>Admin Details</b><br>
username: flight_admin<br>
password: 123 <br>
One can use these admin details to add routes,flights etc..<br>
Note that advance bookings can be made upto 1 week only. <br>
Here I used promo codes also for discounts. All flights are non-stop flights having direct routes. <br>
Tickets are also generated and can be cancelled.




